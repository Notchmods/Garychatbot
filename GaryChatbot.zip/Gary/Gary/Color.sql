﻿CREATE TABLE [dbo].[Table]
(
    [id] INT NOT NULL, 
    [backColor] INT NOT NULL
)
